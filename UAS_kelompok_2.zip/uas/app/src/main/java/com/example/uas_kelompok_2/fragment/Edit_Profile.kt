package com.example.uas_kelompok_2.fragment

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.uas_kelompok_2.R
import com.example.uas_kelompok_2.model.DataHelper
import com.example.uas_kelompok_2.model.User
import kotlinx.android.synthetic.main.activity_edit_profile.btn_Edit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Edit_Profile : AppCompatActivity() {
    private lateinit var dataHelper: DataHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Inisialisasi DataHelper di dalam onCreate
        val dataHelper = DataHelper(this)
        val userid = intent.extras?.getString("id")

        val user = userid?.let { dataHelper.getJadwal(id = String()) }

        // Temukan komponen-komponen dari layout XML (EditText, Button, dsb.)
        val nameEditText: EditText = findViewById(R.id.fullName)
        val emailEditText: EditText = findViewById(R.id.Email)
        val bornEditText: TextView = findViewById(R.id.born)
        val daftarEditText: EditText = findViewById(R.id.Nomor_daftar)
        // ... (ambil komponen lainnya)

        val saveButton: Button = findViewById(R.id.btn_Edit)

        saveButton.setOnClickListener {
            val newName = nameEditText.text.toString()
            val newEmail = emailEditText.text.toString()
            val newBorn = bornEditText.text.toString()
            val newdaftar = daftarEditText.text.toString()


            val idUserToEdit = 1 // Ganti dengan ID user yang ingin diubah
            val newUser = User(newName, newEmail, newBorn, newdaftar)

            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val formattedDate = sdf.format(Date()) // Tanggal baru jika perlu

            dataHelper.editUser(
                idUserToEdit.toString(),
                newUser,
                formattedDate
            ) // Panggil fungsi editUser dari DataHelper

            // Refresh tampilan atau lakukan sesuatu setelah proses edit
            // Misalnya, kembali ke halaman sebelumnya atau tampilkan pesan sukses
            // Setelah proses edit selesai, sebelum menutup Edit_Profile
            val resultIntent = Intent()
            resultIntent.putExtra("editedName", newName)
            resultIntent.putExtra("editedEmail", newEmail)
            resultIntent.putExtra("editedBorn", newBorn)
            resultIntent.putExtra("editedDaftar", newdaftar)
// ... tambahkan data lain jika diperlukan

// Set hasil data yang diubah sebagai result dari Edit_Profile
            setResult(Activity.RESULT_OK, resultIntent)

// Tutup Edit_Profile dan kembali ke fragment_profile_
            finish()

        }
    }
}
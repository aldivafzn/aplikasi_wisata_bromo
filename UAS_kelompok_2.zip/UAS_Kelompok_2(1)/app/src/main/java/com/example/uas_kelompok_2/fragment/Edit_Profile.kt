package com.example.uas_kelompok_2.fragment

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TextView
import com.example.uas_kelompok_2.R
import com.example.uas_kelompok_2.model.DataHelper
import com.example.uas_kelompok_2.model.User
import kotlinx.android.synthetic.main.activity_edit_profile.btn_Edit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Edit_Profile : AppCompatActivity() {
    private lateinit var dataHelper: DataHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Inisialisasi DataHelper di dalam onCreate
        dataHelper = DataHelper(this)

        // Temukan komponen-komponen dari layout XML (EditText, Button, dsb.)
        val nameEditText: EditText = findViewById(R.id.fullName)
        val emailEditText: EditText = findViewById(R.id.Email)
        val bornEditText: TextView = findViewById(R.id.born)
        val daftarEditText: EditText = findViewById(R.id.Nomor_daftar)
        // ... (ambil komponen lainnya)



        val saveButton: Button = findViewById(R.id.btn_Edit)

        // Ambil data pengguna dari database dan isi komponen-komponen formulir
        val idUserToEdit = intent.getIntExtra("userIdToEdit", 0)
        val userData = dataHelper.profile(idUserToEdit)

        val idUserToEdit1 = intent.getIntExtra("userIdToEdit", 0)
        Log.d("Edit_Profile", "Received userIdToEdit: $idUserToEdit")

        val userData1 = dataHelper.profile(idUserToEdit)
        Log.d("Edit_Profile", "Retrieved userData: ${userData.joinToString()}")

        if (userData.isNotEmpty()) {
            nameEditText.setText(userData[0])
            emailEditText.setText(userData[1])
            bornEditText.text = userData[3]// Tanggal lahir
            daftarEditText.setText(userData[2])


        }

        saveButton.setOnClickListener {
            val newName = nameEditText.text.toString()
            val newEmail = emailEditText.text.toString()
            val newBorn = bornEditText.text.toString()
            val newDaftar = daftarEditText.text.toString()

            val newUser = User(newName, newEmail, newBorn, newDaftar)

            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val formattedDate = sdf.format(Date()) // Tanggal baru jika perlu

            dataHelper.editUser(idUserToEdit, newUser, formattedDate)

            // Kirim kembali data yang sudah diubah ke Profile_Fragment
            val resultIntent = Intent()
            resultIntent.putExtra("editedName", newName)
            resultIntent.putExtra("editedEmail", newEmail)
            resultIntent.putExtra("editedBorn", newBorn)
            resultIntent.putExtra("editedDaftar", newDaftar)
            setResult(Activity.RESULT_OK, resultIntent)

            // Tutup Edit_Profile dan kembali ke fragment_profile_
            finish()
        }
    }
}

package com.example.uas_kelompok_2.model

class Jadwal {
    var id_mobil : String = ""
    var keterangan : String = ""
    var kunjungan : String = ""
    constructor( idDokter : String , keterangan : String, kunjungan :String){
         this.id_mobil = idDokter
         this.keterangan = keterangan
        this.kunjungan = kunjungan
     }
}

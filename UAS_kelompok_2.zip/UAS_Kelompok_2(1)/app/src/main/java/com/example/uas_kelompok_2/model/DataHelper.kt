package com.example.uas_kelompok_2.model


import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class DataHelper (var context: Context) : SQLiteOpenHelper(context,
    "data-bromo1", null,1)
    {
        private  val db = this.writableDatabase
        override fun onCreate(db: SQLiteDatabase?) {
            val createTableUser = "CREATE TABLE user ( "+
                        " id_user INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        " nama VARCHAR(50), " +
                        " email VARCHAR(50), " +
                        " nomor VARCHAR(15), " +
                        " tglLahir DATE, " +
                        " password VARCHAR(50)); "
            val createTableMobil =  " CREATE TABLE mobil ( "+
                        " id_mobil INTEGER PRIMARY KEY AUTOINCREMENT, "+
                        " nama VARCHAR(50), " +
                        " spesialis VARCHAR(50)); "
            val createTableJadwal   = " CREATE TABLE jadwal ( "+
                        " id_jadwal INTEGER PRIMARY KEY AUTOINCREMENT, "+
                        " id_user INTEGER, " +
                        " id_mobil INTEGER, "+
                        " kunjungan DATETIME, " +
                        " keterangan VARCHAR(100)," +
                        " FOREIGN KEY(id_user) references user(id_user)," +
                        " FOREIGN KEY(id_mobil) references dokter(id_mobil)); "
            val insertdata = "INSERT INTO mobil (nama,spesialis)VALUES " +
                    "('Jeep ','Off road')," +
                    "('Pick Up ','Barang')," +
                    "('Motor Trail ','Gesit')," +
                    "('Kuda' ,'Jalan Santai')," +
                    "('Motor ATV ','Hiburan')," +
                    "('Sepeda' ,'Refresing'); "
            val insertdatauser = "INSERT INTO user (nama,email,nomor,tglLahir,password)VALUES ('Admin','admin','0834637322' ,'2001-12-09','admin'); "
            val insertDataJadwal = "INSERT INTO jadwal (id_user,id_mobil,kunjungan,keterangan) VALUES (1,1,'2022-11-19','cek kondisi mobil');"
            db?.execSQL(createTableUser)
            db?.execSQL(createTableMobil)
            db?.execSQL(createTableJadwal)
            db?.execSQL(insertdata)
            db?.execSQL(insertdatauser)
            db?.execSQL(insertDataJadwal)
        }
        override fun onUpgrade(db: SQLiteDatabase?,oldVersion: Int,newVersion:
        Int) {
            TODO("Not implemented")}
        fun insertUser (user: User, tgl : String) {
            val cv = ContentValues()
            cv.put("nama", user.nama)
            cv.put("nomor", user.nomor)
            cv.put("email",user.email)
            cv.put("tglLahir" , tgl)
            cv.put("password",user.password)
            val result = db.insert("user", null, cv)
            if (result == (-1).toLong())
                Toast.makeText(context, "FAILED", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(context, "ADD ACCOUNT SUCCESS", Toast.LENGTH_SHORT).show()
        }

        fun insertJadwal (jadwal: Jadwal, idUser: String?) {
            val cv = ContentValues()
            cv.put("id_mobil", jadwal.id_mobil)
            cv.put("kunjungan",jadwal.kunjungan)
            cv.put("keterangan",jadwal.keterangan)
            cv.put("id_user", idUser)
            val result = db.insert("jadwal", null, cv)
            if (result == (-1).toLong())
                Toast.makeText(context, "FAILED", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(context, "TAMBAH JADWAL SUKSES!", Toast.LENGTH_SHORT).show()
        }

        @SuppressLint("Range")
        fun checkUser(email: String, password: String): Int {
            val query = "SELECT * FROM user WHERE email='$email' AND password='$password'"
            val rs = db.rawQuery(query, null)
            if (rs.moveToFirst()) {
                val idUser = rs.getInt(rs.getColumnIndex("id_user"))
                rs.close()

                return idUser
            }
            return -1
        }

        fun getJadwal(id: Int): List<Jadwal>{
            val lsJadwal: MutableList<Jadwal> = ArrayList<Jadwal>()
            val sql = "SELECT mobil.nama, jadwal.kunjungan, jadwal.keterangan FROM jadwal INNER JOIN mobil ON mobil.id_mobil = jadwal.id_mobil WHERE jadwal.id_user = $id"
            val cursor = db.rawQuery(sql, null)
            if(cursor.moveToFirst()) {
                do {
                    val jadwal1 = Jadwal(cursor.getString(0),cursor.getString(1),  cursor.getString(2))
                    lsJadwal.add(jadwal1)

                } while (cursor.moveToNext())
            }
            cursor.close()
            return lsJadwal
        }

        @SuppressLint("Range")
        fun profile(id: Int) : Array<String>{
            val query = "SELECT nama,email,nomor,tglLahir FROM user WHERE id_user=$id"
            val rs = db.rawQuery(query,null)
            if(rs.moveToFirst()) {
                val nama = rs.getString(rs.getColumnIndex("nama"))
                val email = rs.getString(rs.getColumnIndex("email"))
                val nomor = rs.getString(rs.getColumnIndex("nomor"))
                val tgl_lahir = rs.getString(rs.getColumnIndex("tglLahir"))
                val parser = SimpleDateFormat("yyyy-MM-dd", Locale.UK)
                val formatter = SimpleDateFormat("dd-MM-yyyy", Locale.UK)
                val date = parser.parse(tgl_lahir)?.let { formatter.format(it) }
                rs.close()
                return arrayOf(nama,email,nomor,date.toString())
            }
            return arrayOf("","","","","")
        }

        fun editUser(id: Int, user: User, tgl: String) {
            val cv = ContentValues()
            cv.put("nama", user.nama)
            cv.put("nomor", user.nomor)
            cv.put("email", user.email)
            cv.put("tglLahir", tgl)
            cv.put("password", user.password)

            val result = this.db.update("user", cv, "id_user=?", arrayOf(id.toString()))

            if (result == 1)
                Toast.makeText(context, "Data user berhasil diubah", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(context, "Gagal mengubah data user", Toast.LENGTH_SHORT).show()
        }

        fun editJadwal(id: Int, jadwal: Jadwal) {
            val cv = ContentValues()
            cv.put("id_mobil", jadwal.id_mobil)
            cv.put("kunjungan", jadwal.kunjungan)
            cv.put("keterangan", jadwal.keterangan)

            val result = this.db.update("jadwal", cv, "id_jadwal=?", arrayOf(id.toString()))

            if (result == 1)
                Toast.makeText(context, "Data jadwal berhasil diubah", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(context, "Gagal mengubah data jadwal", Toast.LENGTH_SHORT).show()
        }
    }